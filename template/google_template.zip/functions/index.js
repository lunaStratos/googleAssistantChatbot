'use strict';

//기본적인 템플레이트
//콤마찍기, 랜덤 chip, 텍스트코드를 텍스트로 변경 function있음
//json xml 동시지원

//template이름 수정할 것

const {
  dialogflow,
  Suggestions,
  SimpleResponse,
  BasicCard,
  Image,
  Button,
  List,
  Confirmation,
  Permission,
  LinkOutSuggestion,
  MediaObject
} = require('actions-on-google');
const functions = require('firebase-functions');
const request = require('request')
const iconv = require('iconv-lite');
const proj4 = require('proj4');
var xml2js = require('xml2js');
var parser = new xml2js.Parser();

// app
const app = dialogflow({
  debug: true
});


//intent name
const WELCOME_INTENT = 'Default Welcome Intent';
const SAMPLE_INTENT = 'sample';

//List선택
const OPTION_SELECT = 'actions.intent.OPTION' // List선택 (리스트 response 공통)

//basic intent : for quality
const FALLBACK = 'Default Fallback Intent'; //Fallback, 3번 하면 종료
const HELP = 'help'; // 도움말
const SUPPPORT_COMMAND = 'supportCommand'; //지원되는 메뉴
const EXIT = 'exit'; // 종료
//앱 타이 (전역으로 사용)
const appTitle = '다함께 차차차'; //앱 타이틀을 설정

//for chip
let suggestions = ["도움말", "끝내기"]; //칩은 8개까지 생성가능

// 랜덤 칩 메이커 (array[] 가 들어가면 8개의 칩이 생성 )
function chipMaker_shuffle(arrays) {
  var i = 0,
    j = 0,
    temp = null

  for (i = arrays.length - 1; i > 0; i -= 1) {
    j = Math.floor(Math.random() * (i + 1))
    temp = arrays[i]
    arrays[i] = arrays[j]
    arrays[j] = temp
  }
  //Array 만들기
  let newArray = ['도움말', '끝내기'];
  for (let k = 2; k < 7; k++) {
    newArray[k] = arrays[k];
  }
  return newArray;
} // chipMaker_shuffle

// 콤마 찍기 => 화폐나 사람 수
// 숫자가 들어오면 String
function numberWithCommas(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
} //numberWithCommas

//지도 변환 proj4 사용시

// var from = 'TM128'
// var to = 'WGS84'
// proj4.defs('WGS84', "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs");
// proj4.defs('TM128', '+proj=tmerc +lat_0=38 +lon_0=128 +k=0.9999 +x_0=400000 +y_0=600000 +ellps=bessel +units=m +no_defs +towgs84=-115.80,474.99,674.11,1.16,-2.31,-1.63,6.43');
// var xy = [gis_X, gis_Y];
// var katecToWGS84 = proj4(from, to, xy); // WGS84 => TM128
// //지도링크 생성 18줌으로 고정
// console.log(katecToWGS84[0]) // 큰값
// console.log(katecToWGS84[1]) // 작은값
//
// let naverMapLink = 'http://maps.naver.com/?menu=location&mapMode=0&lat=' + katecToWGS84[1] + '&lng=' + katecToWGS84[0] + '&dlevel=13&enc=b64mapMode'
// let daumMapLink = 'https://map.daum.net/link/map/' + katecToWGS84[1] + ',' + katecToWGS84[0]
// let googleMapLink = 'https://www.google.com/maps/@' + katecToWGS84[1] + ',' + katecToWGS84[0] + ',18z';

//코드 => 상품 브랜드
function switchCodeToProduct(text) {
  let returnText = '';
  switch (text) {
    case 'A':
      returnText = ''
      break;
    case 'B':
      returnText = ''
      break;
    case 'C':
  }
  return returnText;
}


//브랜드 코드 받아서 이름, 이미지
function switchCodeToBrand(text) {
  let returnText = '';
  let image = '';

  switch (text) {
    case 'SKE':
      returnText = 'SK에너지'
      image = 'https://storage.googleapis.com/finalrussianroulette.appspot.com/oilStation/sk_logo.png'
      break;
    case 'GSC':
      returnText = 'GS칼텍스'
      image = 'https://storage.googleapis.com/finalrussianroulette.appspot.com/oilStation/gs_logo.png'
      break;
    case 'HDO':
      returnText = '현대오일뱅크'
      image = 'https://storage.googleapis.com/finalrussianroulette.appspot.com/oilStation/hyundai_logo.jpg'
      break;
    case 'SOL':
      returnText = 'S-OIL'
      image = 'https://storage.googleapis.com/finalrussianroulette.appspot.com/oilStation/s-oil_logo.jpg'
      break;
  }
  const arrayreturn = [returnText, image, ] // 실제브랜드, 로고주소, 브랜드주유소사진
  return arrayreturn;
} // switchCodeToBrand

//현재 날짜
function date_return() {

  const date = new Date()
  const korDate = new Date(date.getTime() + 1000 * 60 * 60 * 9);
  const year = korDate.getFullYear() + ''; //String
  const month = ('0' + (korDate.getMonth() + 1)).slice(-2) //0추가
  const day = ('0' + korDate.getDate()).slice(-2) //0추가

  const todayText = year + '년 ' + month + '월 ' + day + '일';
  return todayText;
} //date_return

//Request
function requesetParsing(insertData, apiType, callback) {
  let url = ''; //URL

  //기본 요청 코드
  let forms = {
    code: '',
    out: 'json'
  }

  //apiType으로 분리
  switch (apiType) {
    case '': //
      //http://www.opinet.co.kr/api/searchByName.do?code=F367181010&out=json&osnm=보라매&area=01
      url = "http://www.opinet.co.kr/api/searchByName.do";
      forms.osnm = insertData.osnm; // 주유소 이름
      //지역은 있을수도 없을수도 있음
      if (insertData.area != null || insertData.area != undefined || insertData.area != '') {
        forms.area = insertData.area;
      }
      break;
    case 'XML': // xml
      //http://www.opinet.co.kr/api/searchByName.do?code=F367181010&out=json&osnm=보라매&area=01
      url = "http://www.opinet.co.kr/api/searchByName.do";
      forms.out = 'xml';
      if (insertData.area != null || insertData.area != undefined || insertData.area != '') {
        forms.area = insertData.area;
      }
      break;
    case 'jquery': // jquery
      //http://www.opinet.co.kr/api/searchByName.do?code=F367181010&out=json&osnm=보라매&area=01
      url = "http://www.opinet.co.kr/api/searchByName.do";
      forms.out = 'xml';
      break;

  } // switch

  console.log('forms: ', forms);

  //공통
  request({
    method: 'GET',
    url: url,
    encoding: null,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/603.1.1 (KHTML, like Gecko) Version/9.1.2 Safari/601.7.7'
    },
    timeout: 1000 * 30,
    qs: forms //form 입력 Get시 qs사용, post시 form사용
  }, function(err, res, responseBody) {
    //json받기
    console.log(res.headers['content-type'])
    const html = responseBody.toString()
    console.log('html ', html);

    let result = ''
    let OilArray = '';

    //json
    if (forms.out == 'json') {
      result = JSON.parse(html);
      console.log('result', result);
      OilArray = result.RESULT.OIL;

      if (OilArray[0] == undefined) {
        //callback
        callback(null, {
          code: 300,
          result: 'fail'
        });

      } else {
        //callback

        callback(null, {
          code: 200,
          list: OilArray,
          result: 'success'
        });

      }

    } else if (forms.out == 'jquery'){ //jquery인 경우
        const $ = cheerio.load(iconvlite.decode(responseBody, 'EUC-KR'));
        //console.log("JSON.stringify: ", body.toString());
        let array = [];

        $(".tbl_board table tbody tr").each(function(index) {
          let tempJson = {};
          let noData = '검색결과를 찾을수 없습니다.';
          if (index != 0) { // td의 0번은 무시
            $(this).find('td').each(function(index2) {
              console.log('index2: ', index2)
              let no = $(this).find('.ac em').text();
              let song = $(this).find('.pl8 a').attr('title');
              let song2 = $(this).find('.pl8 span').attr('title');
              let singer = $(this).find('.tit.pl8 a').text();
              let nodata = $(this).text();
              console.log(nodata)
              if ("* 검색된 데이터가 없습니다." == nodata) {
                callback(err, {
                  code: 300,
                });
                return;
              } else {
                switch (index2) {
                  case 0:
                    tempJson.brand = 'kumyoung'
                    tempJson.no = no
                    break;
                  case 1: //
                    if (song == undefined) {
                      tempJson.song = song2
                    } else {
                      tempJson.song = song
                    }

                    break;
                  case 2:
                    tempJson.singer = singer
                    break;
                }
              }

            });
            array.push(tempJson);
          }

        });
        console.log(array)

        callback(null, {
          code: 200,
          list: array,
          result: 'success'
        });

    }else { //DetailById 인 경우
      parser.parseString(html, function(err, XmlJson) {
        console.log(XmlJson);
        console.log(JSON.stringify(XmlJson));

        const originalList = XmlJson.RESULT

        if (originalList != '\r\n \r\n') { // 에러없음
          const xmlList = originalList.OIL[0]

          callback(null, {
            code: 200,
            list: xmlList,
            status: 'success'
          });
        } else {
          callback(null, {
            code: 400,
            list: '',
            status: 'fail'
          });
        }

      }); //xml parser

    } // detailById　구분

  });

} //request function

//Promise
const asyncTask = (insertData, requestCase) => new Promise(function(resolved, rejected) {
  requesetParsing(insertData, requestCase, function(err, result) {
    if (err) {
      rejected(err);
    } else {
      resolved(result);
    }
  });
});

// Welcome intent.
app.intent(WELCOME_INTENT, (conv) => {
  console.log("WELCOME_INTENT");
  conv.data.fallbackCount = 0;

  //console.log("conv: " + JSON.stringify(conv));
  //console.log("action: " + JSON.stringify(conv.action));

  // let text
  let displayText = '';
  let speechText = '';

  let imageLink = 'https://storage.googleapis.com/finalrussianroulette.appspot.com/movieApp/moiveSell.jpg';
  let text = appTitle + '에 오신걸 환영합니다.';
  let title = appTitle + ' 입니다';
  let subtitle = ''
  let convResponse = 'original'
  let suggestionList = suggestions;

  let welcomeSound = "https://storage.googleapis.com/finalrussianroulette.appspot.com/bgm/faces.ogg";
  if (conv.user.last.seen) {
    //json 형태로 보내기
    displayText = appTitle + "에 오신것을 환영합니다. 전국 주유소의 가격과 현재 위치 혹은 설정한 위치로 가격비교를 할 수 있습니다.";
    speechText = "<speak><par>" +
      '<media><speak><break time="1s"/>' + displayText + "</speak></media>" +
      '<media fadeOutDur="1s" end = "12s"><audio src="' + welcomeSound + '"/></media>' +
      '</par></speak>';

  } else {

    displayText = appTitle + "에 오신것을 환영합니다. 전국 주유소의 가격과 현재 위치 혹은 설정한 위치로 가격비교를 할 수 있습니다.";
    speechText = "<speak><par>" +
      '<media><speak><break time="1s"/>' + displayText + "</speak></media>" +
      '<media fadeOutDur="1s" end = "12s"><audio src="' + welcomeSound + '"/></media>' +
      '</par></speak>';

  }

  //ask
  conv.ask(new SimpleResponse({
    speech: speechText,
    text: displayText,
  }));
  conv.ask(new Suggestions(suggestionList));
  conv.ask(new BasicCard({
    text: text,
    subtitle: subtitle,
    title: title,
    image: new Image({
      url: imageLink,
      alt: '이미지',
    }),
  }));


});

//
function general_return(conv, result) {
  // let text
  let displayText = '';
  let speechText = '';

  let imageLink = 'https://storage.googleapis.com/finalrussianroulette.appspot.com/parcelLive/error.jpg';
  let text = '';
  let title = '';
  let subtitle = ''
  let suggestionList = suggestions;
  if (result.code != 200) { //300과 400 에러시
    //문제있음
    imageLink = "https://storage.googleapis.com/finalrussianroulette.appspot.com/parcelLive/error.jpg";
    title = "서버연결 에러";
    displayText = "찾으시는 시도의 이름이 없습니다. 다른 시도 이름을 해 주세요.";
    speechText = displayText;

  } else { // no problem -> List

    //PRICE가격, DIFF등락률 (%)
    const list = result.list;


    //ask
    conv.ask(new SimpleResponse({
      speech: speechText,
      text: displayText,
    }));
    conv.ask(new Suggestions(suggestions));
    conv.ask(new BasicCard({
      text: text,
      subtitle: subtitle,
      title: title,
      image: new Image({
        url: imageLink,
        alt: '이미지',
      }),
    }));

  } // if 200 or 300 400
}


//리스트 형태로 Return 하는 것 =>
function list_return(conv, result, requestType) {
  // let text
  let displayText = '';
  let speechText = '';

  let imageLink = '';
  let text = '';
  let title = '';
  let subtitle = ''
  let suggestionList = suggestions;

  if (result.code != 200) { //300과 400 에러시
    //문제있음
    imageLink = "https://storage.googleapis.com/finalrussianroulette.appspot.com/parcelLive/error.jpg";
    title = "서버연결 에러";
    displayText = "죄송합니다. 찾은 결과 주유소 정보가 없습니다. 다른 명령을 시도해 주세요.";
    speechText = displayText;

    //ask
    conv.ask(new SimpleResponse({
      speech: speechText,
      text: displayText,
    }));
    conv.ask(new Suggestions(suggestions));
    conv.ask(new BasicCard({
      text: text,
      subtitle: subtitle,
      title: title,
      image: new Image({
        url: imageLink,
        alt: '이미지',
      }),
    }));

  } else { // no problem -> List

    //ArrayList
    const ArrayList = result.list;

    let selectArray = []; //건드리지 말것
    let itemMake = {}; // 건드리지 말것

    for (let i = 0; i < ArrayList.length; i++) {

      let SELECTION_KEY = i; // 선택키
      let optionInfoInsert = {
        "key": SELECTION_KEY
      }


      selectArray[i + 2] = {
        gasStationName: gasStationName,
        price: price,
        gis_X: gis_X,
        gis_Y: gis_Y,
        distance: distance,
        brandImage: brandImage,
        gasStationCode: codeNum
      }

      //make items
      itemMake[i + 2] = {
        optionInfo: 'optionInfoInsert',
        title: 'title',
        description: 'descriptionDistanceOrAddress',
        image: new Image({
          url: IMG_URL,
          alt: 'alt_text',
        })
      } // itemMake

    } //for

    let length3 = 3 - ArrayList.length;

    //3개 이하의 리스트 생성기
    for (let i = 0; i < length3; i++) {
      let SELECTION_KEY = '';
      let IMG_URL = '';
      let alt_text = '';
      IMG_URL = 'https://storage.googleapis.com/finalrussianroulette.appspot.com/noReaBang/none.jpg';
      alt_text = '-';

      selectArray[ArrayList.length + 2] = " "; // 외부 모듈
      //make items
      itemMake[ArrayList.length + 2] = {
        title: " ",
        description: " ",
        image: new Image({
          url: IMG_URL,
          alt: alt_text,
        })
      } // itemMake
    } //for

    //List
    //이벤트에 actions_intent_OPTION 이거 안넣으면 아래의 title에러 남
    //MalformedResponse expected_inputs[0].input_prompt.rich_initial_prompt: 'title' must not be empty.
    conv.data.ArrayList = ArrayList;

    //사용자편의를 위한 텍스트 생성 = 한눈에 보기


    //response부분.
    conv.ask(new SimpleResponse({
      speech: speechText,
      text: displayText
    }));
    conv.ask(new List({
      title: '검색결과',
      items: itemMake
    }));
    conv.ask(new Suggestions(suggestions));

  } // if 200 or 300 400

}

//sampleRequest_intent
app.intent('sampleRequest_intent', (conv) => {
  conv.data.fallbackCount = 0;

  //json 형태로 보내기
  let insertData = {
    'none': '보낼 데이터 없음',
  }

  let requestType = 'requestType';
  //request
  return asyncTask(insertData, requestType)
    .then(function(result) {
      //로그 확인용
      console.log("result : " + JSON.stringify(result));
      test_return(conv, result);

    });

}); // sampleRequest_intent

//sampleRequestList_intent
app.intent('sampleRequestList_intent', (conv) => {
  conv.data.fallbackCount = 0;
  let city = conv.parameters['city']; //parameters

  //json 형태로 보내기
  let insertData = {
    'prodcd': oilType,
    'area': city
  }

  let requestType = 'lowTop10';
  //request
  return asyncTask(insertData, requestType)
    .then(function(result) {
      //로그 확인용
      console.log("result : " + JSON.stringify(result));
      list_return(conv, result, requestType)

    });

}); //sampleRequestList_intent


//location_first 위치정보
app.intent('location_first', (conv, params, confirmationGranted) => {
  conv.data.fallbackCount = 0;
  console.log("location_first")
  console.log("confirmationGranted: ", confirmationGranted)
  console.log(params)
  if (params) { //권한 없으면 Object.keys(confirmationGranted).length === 0

    //https://developers.google.com/actions/assistant/helpers
    //위치 퍼미션 받는 intent

    // Choose one or more supported permissions to request:
    // NAME, DEVICE_PRECISE_LOCATION, DEVICE_COARSE_LOCATION
    const options = {
      context: ' ',
      // Ask for more than one permission. User can authorize all or none.
      permissions: ['DEVICE_PRECISE_LOCATION'],
    };
    conv.ask(new Permission(options));

  } else { // 권한 있음




  }

}); // 'location_first'



//중요!! : 이벤트에 actions_intent_PERMISSION 넣기
//위치정보 권한 수락 YES
//No 인 경우는   conv.followup("이벤트이름"); 으로 이벤트처리 가능
app.intent('location_get_permission', (conv, params, confirmationGranted) => {
  console.log("location_get_permission")
  console.log('params', params)
  console.log("confirmationGranted: ", confirmationGranted)

  if (confirmationGranted == false) { //권한 없으면

    conv.ask(new SimpleResponse({
      speech: '권한이 없는 관계로 위치정보를 통한 검색을 하지 않습니다. 다른 명령을 시도해 주세요.',
      text: '권한이 없는 관계로 위치정보를 통한 검색을 하지 않습니다. 다른 명령을 시도해 주세요.',
    }));
    conv.ask(new Suggestions(suggestions));
    conv.ask(new BasicCard({
      text: '위치정보를 불러오지 못했습니다.',
      subtitle: '',
      title: '위치정보 취소',
      image: new Image({
        url: 'https://storage.googleapis.com/finalrussianroulette.appspot.com/noReaBang/none.jpg',
        alt: '이미지',
      }),
    }));

  } else {


  } //if


}); // location_get_permission


//2~30까지 가능
//REF: https://developers.google.com/actions/assistant/responses#list
app.intent(OPTION_SELECT, (conv, params, option) => {
  conv.data.fallbackCount = 0;
  const ArrayList = conv.data.ArrayList;

  let displayText = '죄송합니다. 화면을 출력할 수 있는 기기가 아닙니다. 다른 명령을 말해주세요.';
  let speechText = '';
  let imageLink = '';
  let text = '';
  let title = '';
  let subtitle = ''
  let suggestionList = suggestions;
  //위도 ,경도 ,Zoom 범위


  if (option && selectGasStation.hasOwnProperty(option)) { //리스트 선택시
    const getArray = ArrayList[option]

  }

});



// =======================================================================
// =======================================================================
// =======================================================================
// =======================================================================
// ============================퀄리티를 위한 영역=============================
// =======================================================================
// =======================================================================
// =======================================================================
// =======================================================================


// FALLBACK
app.intent(FALLBACK, (conv) => {
  console.log("FALLBACK");

  // let text
  let displayText = '';
  let speechText = '';
  let imageLink = '';
  let text = '';
  let title = '죄송합니다';
  let subtitle = ''
  let flow = 'fallback';
  let convResponse = 'original'

  let count = conv.data.fallbackCount;
  count++;
  conv.data.fallbackCount = count;

  if (count < 3) {

    if (count === 1) {
      displayText = '제가 잘 모르는 명령어 입니다. "지원되는 메뉴"을 말하시면 지원되는 회사를 아실 수 있습니다. ';
      imageLink = "https://storage.googleapis.com/finalrussianroulette.appspot.com/coinimage/dogeza.jpg";
      speechText = displayText;
    } else if (count === 2) {
      displayText = '죄송합니다. 현재 위치에서 가장 싼 주유소를 알고 싶으신가요? "내 위치 최저가 주유소" 이라고 말하시면 됩니다.';
      imageLink = "https://storage.googleapis.com/finalrussianroulette.appspot.com/coinimage/dogeza2.jpg";
      speechText = displayText;
    }

    //ask
    conv.ask(new SimpleResponse({
      speech: speechText,
      text: displayText,
    }));
    conv.ask(new Suggestions(suggestions));
    conv.ask(new BasicCard({
      text: text,
      subtitle: subtitle,
      title: title,
      image: new Image({
        url: imageLink,
        alt: '이미지',
      }),
    }));

  } else if (count > 2) { // 3번 이상은 종료시킴
    displayText = '정말로 죄송합니다. 제가 잘 모르는 명령이거나 인식이 실패했습니다. 앱을 종료하겠습니다. ';
    imageLink = "https://storage.googleapis.com/finalrussianroulette.appspot.com/ramenImage/DQmeEHtAtdRcA64c9dJPSNFeArbQEWVbcNfoTpix2EjJ484_1680x8400.png";
    speechText = displayText;

    conv.close(new SimpleResponse({
      speech: speechText,
      text: displayText,
    }), new BasicCard({
      text: text,
      subtitle: subtitle,
      title: title,
      image: new Image({
        url: imageLink,
        alt: '이미지',
      }),
    }));

  } //if 1


});

// SUPPPORT_COMMAND
app.intent(SUPPPORT_COMMAND, (conv) => {
  console.log("SUPPPORT_COMMAND");

  // let text
  let displayText = '지원되는 메뉴는 다음과 같습니다. \n* 내 위치의 최저가 주유소 \n* 전국 평균가격 조회 \n* 성남시(일반시,군,구)의 주유소 최저가격 \n* 서울특별시(광역시,도)의 주유소 평균가격 을 지원하고 있습니다.';
  let speechText = '지원되는 메뉴는 다음과 같습니다. 내 위치의 최저가 주유소, 전국 평균가격 조회 , 시군구의 주유소 최저가격 , 시도의 주유소 평균가격 을 지원하고 있습니다.';
  let imageLink = 'https://storage.googleapis.com/finalrussianroulette.appspot.com/ramenImage/help.jpg';
  let text = '';
  let title = '';
  let subtitle = ''

  //ask
  conv.ask(new SimpleResponse({
    speech: speechText,
    text: displayText,
  }));
  conv.ask(new Suggestions(suggestions));
  conv.ask(new BasicCard({
    text: text,
    subtitle: subtitle,
    title: title,
    image: new Image({
      url: imageLink,
      alt: '이미지',
    }),
  }));

}); //SUPPPORT_COMMAND


// HELP
app.intent(HELP, (conv) => {
  console.log("HELP");
  conv.data.fallbackCount = 0;

  let displayText = appTitle + '는 전국의 주유소 정보와 현위치의 최저가를 알 수 있습니다.';
  let speechText = '';
  // let subModule
  let imageLink = 'https://storage.googleapis.com/finalrussianroulette.appspot.com/ramenImage/help.jpg';
  let text = '';
  let title = '설명서';
  let subtitle = ''

  let lastConv = '다음 질문을 해 주세요.';
  let flow = 'help';
  let convResponse = 'original'
  let suggestionList = suggestions;

  speechText = displayText;

  //ask
  conv.ask(new SimpleResponse({
    speech: speechText,
    text: displayText,
  }));
  conv.ask(new Suggestions(suggestionList));
  conv.ask(new BasicCard({
    text: text,
    subtitle: subtitle,
    title: title,
    image: new Image({
      url: imageLink,
      alt: '이미지',
    }),
  }));
  conv.ask(new SimpleResponse(lastConv));
});


//EXIT
app.intent(EXIT, (conv) => {
  console.log("EXIT");
  conv.data.fallbackCount = 0;
  let displayText = '앱을 종료합니다. 이용해 주셔서 감사합니다냥!';
  let speechText = '';

  // let text
  let name = '끝내기';
  let imageLink = 'https://storage.googleapis.com/finalrussianroulette.appspot.com/parcelLive/bye.jpg';

  let text = '';
  let title = appTitle + '을 종료 합니다';
  let subtitle = ''
  let convResponse = 'original'
  let lastConv = '';
  let flow = 'end';
  speechText = displayText;

  //ask
  conv.close(new SimpleResponse({
    speech: speechText,
    text: displayText,
  }));
  conv.close(new BasicCard({
    text: text,
    subtitle: subtitle,
    title: title,
    image: new Image({
      url: imageLink,
      alt: '이미지',
    }),
  }));
});

//test
app.intent('test', (conv) => {
  conv.data.fallbackCount = 0;
  console.log("test")

  //ask
  conv.ask(new SimpleResponse({
    speech: '권한이 없습니다.',
    text: '권한이 없습니다.',
  }));
  conv.ask(new Suggestions(suggestionChipNew));
  conv.ask(new BasicCard({
    text: text,
    subtitle: subtitle,
    title: title,
    image: new Image({
      url: imageLink,
      alt: '이미지',
    }),
  }));

}); // test

//media
app.intent('media', (conv) => {
  conv.data.fallbackCount = 0;
  console.log("media")

  conv.ask(new SimpleResponse({
    speech: speechText,
    text: displayText,
  }));
  conv.ask(new Suggestions(suggestions));
  conv.ask(new MediaObject({
    name: title,
    url: mediaUrl,
    description: text,
    icon: new Image({
      url: imageLink,
      alt: title,
    }),
  }));

}); // media

// Action name is different to method name.
// my action name is dialogv2. So If you want another name, please rename it.
// action name: dialogv2 => change your action name.
exports.template = functions.https.onRequest(app);

// for help link
// 1. V1 and v2 different : https://developers.google.com/actions/reference/nodejs/lib-v1-migration
// 2. fulfillment design: https://developers.google.com/actions/dialogflow/fulfillment
